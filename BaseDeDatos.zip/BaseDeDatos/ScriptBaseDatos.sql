USE [master]
GO
/****** Object:  Database [TUYADB]    Script Date: 18/02/2023 7:55:15 p.�m. ******/
CREATE DATABASE [TUYADB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'TUYADB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\TUYADB.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'TUYADB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\TUYADB_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [TUYADB] SET COMPATIBILITY_LEVEL = 160
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [TUYADB].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [TUYADB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [TUYADB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [TUYADB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [TUYADB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [TUYADB] SET ARITHABORT OFF 
GO
ALTER DATABASE [TUYADB] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [TUYADB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [TUYADB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [TUYADB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [TUYADB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [TUYADB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [TUYADB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [TUYADB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [TUYADB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [TUYADB] SET  DISABLE_BROKER 
GO
ALTER DATABASE [TUYADB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [TUYADB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [TUYADB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [TUYADB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [TUYADB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [TUYADB] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [TUYADB] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [TUYADB] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [TUYADB] SET  MULTI_USER 
GO
ALTER DATABASE [TUYADB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [TUYADB] SET DB_CHAINING OFF 
GO
ALTER DATABASE [TUYADB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [TUYADB] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [TUYADB] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [TUYADB] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [TUYADB] SET QUERY_STORE = ON
GO
ALTER DATABASE [TUYADB] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [TUYADB]
GO
/****** Object:  Table [dbo].[CLIENTE]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CLIENTE](
	[Id_Cliente] [int] NOT NULL,
	[Nombre] [varchar](40) NOT NULL,
	[Apellido] [varchar](40) NOT NULL,
	[Direccion] [varchar](200) NOT NULL,
 CONSTRAINT [PK_CLIENTE] PRIMARY KEY CLUSTERED 
(
	[Id_Cliente] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DETALLE_FACTURA]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DETALLE_FACTURA](
	[Id_Factura] [int] NOT NULL,
	[Id_Item] [int] NOT NULL,
	[Id_Producto] [int] NOT NULL,
	[Cantidad] [decimal](5, 2) NOT NULL,
	[Valor] [decimal](10, 2) NOT NULL,
	[Total] [decimal](10, 2) NOT NULL,
 CONSTRAINT [PK_DETALLE_FACTURA] PRIMARY KEY CLUSTERED 
(
	[Id_Factura] ASC,
	[Id_Item] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FACTURA]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FACTURA](
	[Id_Factura] [int] NOT NULL,
	[Id_Cliente] [int] NOT NULL,
	[Fecha] [datetime] NOT NULL,
 CONSTRAINT [PK_FACTURA] PRIMARY KEY CLUSTERED 
(
	[Id_Factura] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PEDIDO]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PEDIDO](
	[Id_Pedido] [int] NOT NULL,
	[Id_Factura] [int] NOT NULL,
	[Valor_Total] [decimal](10, 2) NOT NULL,
	[Fecha] [datetime] NOT NULL,
	[Estado] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_PEDIDO] PRIMARY KEY CLUSTERED 
(
	[Id_Pedido] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PRODUCTO]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PRODUCTO](
	[Id_Producto] [int] NOT NULL,
	[Nombre] [varchar](40) NOT NULL,
	[Valor] [decimal](10, 2) NOT NULL,
	[Cantidad] [decimal](5, 2) NOT NULL,
 CONSTRAINT [PK_PRODUCTO] PRIMARY KEY CLUSTERED 
(
	[Id_Producto] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[DETALLE_FACTURA]  WITH CHECK ADD  CONSTRAINT [FK_DETALLE_FACTURA_FACTURA] FOREIGN KEY([Id_Factura])
REFERENCES [dbo].[FACTURA] ([Id_Factura])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[DETALLE_FACTURA] CHECK CONSTRAINT [FK_DETALLE_FACTURA_FACTURA]
GO
ALTER TABLE [dbo].[DETALLE_FACTURA]  WITH CHECK ADD  CONSTRAINT [FK_DETALLE_FACTURA_PRODUCTO] FOREIGN KEY([Id_Producto])
REFERENCES [dbo].[PRODUCTO] ([Id_Producto])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[DETALLE_FACTURA] CHECK CONSTRAINT [FK_DETALLE_FACTURA_PRODUCTO]
GO
ALTER TABLE [dbo].[FACTURA]  WITH CHECK ADD  CONSTRAINT [FK_FACTURA_CLIENTE] FOREIGN KEY([Id_Cliente])
REFERENCES [dbo].[CLIENTE] ([Id_Cliente])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FACTURA] CHECK CONSTRAINT [FK_FACTURA_CLIENTE]
GO
ALTER TABLE [dbo].[PEDIDO]  WITH CHECK ADD  CONSTRAINT [FK_PEDIDO_FACTURA] FOREIGN KEY([Id_Factura])
REFERENCES [dbo].[FACTURA] ([Id_Factura])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PEDIDO] CHECK CONSTRAINT [FK_PEDIDO_FACTURA]
GO
/****** Object:  StoredProcedure [dbo].[consultarClientes]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ================================================
-- Procedimiento Almacenado para Consultar Clientes
-- ================================================
CREATE PROCEDURE [dbo].[consultarClientes]
AS
SELECT * FROM CLIENTE
GO
/****** Object:  StoredProcedure [dbo].[consultarPedidoId]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ================================================
-- Procedimiento Almacenado para Consultar Pedido
-- ================================================
CREATE PROCEDURE [dbo].[consultarPedidoId]
@Id_Pedido INT
AS
SELECT  dbo.PEDIDO.*,
	    dbo.CLIENTE.NOMBRE+' '+dbo.CLIENTE.APELLIDO NOMBRE,
		dbo.CLIENTE.DIRECCION
FROM    dbo.CLIENTE INNER JOIN
        dbo.FACTURA ON dbo.CLIENTE.Id_Cliente = dbo.FACTURA.Id_Cliente INNER JOIN
        dbo.PEDIDO ON dbo.FACTURA.Id_Factura = dbo.PEDIDO.Id_Factura
 WHERE  dbo.PEDIDO.Id_Pedido = @Id_Pedido;
GO
/****** Object:  StoredProcedure [dbo].[consultarProductos]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ================================================
-- Procedimiento Almacenado para Consultar Productos
-- ================================================
CREATE PROCEDURE [dbo].[consultarProductos]
AS
SELECT * FROM PRODUCTO
GO
/****** Object:  StoredProcedure [dbo].[facturar]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ================================================
-- Procedimiento Almacenado para el proceso de Facturar
-- ================================================
CREATE PROCEDURE [dbo].[facturar]
@DatosFactura VARCHAR(MAX),
@CodigoError INT OUTPUT,
@MensajeError VARCHAR(MAX) OUTPUT
AS
DECLARE @PedidoGenerado INT;
DECLARE @fechaActual DATETIME;
DECLARE @direccion VARCHAR(200);
DECLARE @idFacturaGeneral INT;
DECLARE @idFactura INT;
DECLARE @idCliente INT;
DECLARE @fecha datetime;
DECLARE @idItem int;
DECLARE @idProducto int;
DECLARE @Cantidad decimal(5,2);
DECLARE @Valor decimal(10,2);
DECLARE @ValorTotal decimal(10,2)=0;
DECLARE @Total decimal(10,2);
DECLARE @CerrarCursorFactura INT =0;
DECLARE @CerrarCursorDetalle INT =0;
BEGIN TRANSACTION 
BEGIN TRY
	
	-- Declara cursor para obtener datos del encabezado de la factura
	DECLARE FacturaCursor CURSOR FOR
		SELECT *
		  FROM OPENJSON(@DatosFactura,N'$.DatosFactura')
		   WITH (
			idFactura int '$.IdFactura',
			idCliente int '$.IdCliente',
			fecha datetime '$.Fecha'
		  );
	OPEN FacturaCursor;
	SET @CerrarCursorFactura =1;
	
	-- Asigna Primer Registro
	FETCH NEXT FROM FacturaCursor  
	INTO @idFactura, @idCliente, @fecha;

	-- Recorreo el Cursor e Inserta en Factura
	WHILE @@FETCH_STATUS = 0  	
	BEGIN  
		
		-- Inserta Factura
		EXEC insertarFactura @idFactura, @idCliente, @fecha, @CodigoError OUTPUT, @MensajeError OUTPUT;		
		
		-- Valida C�digo de Error
		IF @CodigoError <> 0 
		BEGIN	
			CLOSE FacturaCursor;
			DEALLOCATE FacturaCursor;
			ROLLBACK TRANSACTION;
			RETURN;
		END;

		-- Asigna Siguiente Registro
		FETCH NEXT FROM FacturaCursor  
		INTO @idFactura, @idCliente, @fecha;  
	END  	

	-- Cierra Cursor
	CLOSE FacturaCursor;
	DEALLOCATE FacturaCursor;
	SET @CerrarCursorFactura = 0;
	
	-- Declara cursor para obtener datos del encabezado de la factura
	DECLARE DetalleCursor CURSOR FOR
		SELECT *
		  FROM OPENJSON(@DatosFactura,N'$.DatosDetalle')
		   WITH (
			idFactura int '$.IdFactura',
			idItem int '$.IdItem',
			idProducto int '$.IdProducto',
			Cantidad decimal(5,2) '$.Cantidad',
			Valor decimal(10,2) '$.Valor',
			Total decimal(10,2) '$.Total'
		  );
	OPEN DetalleCursor;
	SET @CerrarCursorDetalle =1;

	-- Asigna Primer Registro
	FETCH NEXT FROM DetalleCursor  
	INTO @idFactura, @idItem, @idProducto, @Cantidad, @Valor, @Total;  

	-- Recorreo el Cursor e Inserta en Detalle Factura
	WHILE @@FETCH_STATUS = 0  	
	BEGIN  
		-- Inserta Detalle de Factura
		EXEC insertarDetalleFactura @idFactura, @idItem, @idProducto, @Cantidad, @Valor, @Total, @CodigoError OUTPUT, @MensajeError OUTPUT;
		SET @ValorTotal = @ValorTotal + @Total; 

		-- Valida C�digo de Error
		IF @CodigoError <> 0 
		BEGIN	
			CLOSE DetalleCursor;
			DEALLOCATE DetalleCursor;
			ROLLBACK TRANSACTION;
			RETURN;
		END;

		-- Asigna Siguiente Registro
		FETCH NEXT FROM DetalleCursor  
		INTO @idFactura, @idItem, @idProducto, @Cantidad, @Valor, @Total;  
	END  	

	-- Cierra Cursor
	CLOSE DetalleCursor;
	DEALLOCATE DetalleCursor;
	SET @CerrarCursorDetalle = 0;

	-- Obtiene c�digo del siguiente pedido.
	SELECT @PedidoGenerado=MAX([id_Pedido])+1 FROM PEDIDO;

	-- Obtiene Direcci�n del Cliente
	SELECT @direccion =[Direccion] FROM CLIENTE WHERE Id_Cliente = @idCliente;

	--  Asigna Fecha Actual
	SET @fechaActual = CONVERT(DATETIME,SYSDATETIME(), 102);
	
	-- Inserta el Pedido
	EXECUTE insertarPedido @PedidoGenerado, @idFactura, @ValorTotal, @fechaActual,'Enviado', @CodigoError OUTPUT, @MensajeError OUTPUT;
	
	-- Valida C�digo de Error
	IF @CodigoError <> 0 
	BEGIN	
		ROLLBACK TRANSACTION;
		RETURN;
	END;
	
	-- Finaliza sin Error.
	SET @CodigoError=0;
	SET @MensajeError=concat('{"PedidoGenerado:"',@PedidoGenerado,'}');
	COMMIT TRANSACTION; 
END TRY
BEGIN CATCH
	SET @CodigoError=ERROR_NUMBER();
	SET @MensajeError=ERROR_MESSAGE();
	ROLLBACK TRANSACTION

	-- Cierra Cursor Factura
	IF @CerrarCursorFactura = 1
	BEGIN
		CLOSE FacturaCursor;
		DEALLOCATE FacturaCursor;
	END;

	-- Cierra Cursor Detalle
	IF @CerrarCursorDetalle = 1
	BEGIN
		CLOSE DetalleCursor;
		DEALLOCATE DetalleCursor;
	END;
END CATCH;
GO
/****** Object:  StoredProcedure [dbo].[insertarCliente]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ================================================
-- Procedimiento Almacenado para Crear Clientes
-- ================================================
CREATE PROCEDURE [dbo].[insertarCliente]
@Id_Cliente INT,
@Nombre VARCHAR(40),
@Apellido VARCHAR(40),
@Direccion VARCHAR(200),
@CodigoError INT=0 OUT,
@MensajeError VARCHAR(MAX) OUT
AS
BEGIN TRY
	INSERT INTO CLIENTE VALUES (@Id_Cliente,@Nombre,@Apellido,@Direccion); 
	SET @CodigoError=0;
	SET @MensajeError='';
END TRY
BEGIN CATCH
	SET @CodigoError=ERROR_NUMBER();
	SET @MensajeError='[insertarCliente] '+ERROR_MESSAGE();
END CATCH;
GO
/****** Object:  StoredProcedure [dbo].[insertarDetalleFactura]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ================================================
-- Procedimiento Almacenado para Crear Detalles
-- ================================================
CREATE PROCEDURE [dbo].[insertarDetalleFactura]
@Id_Factura INT,
@Id_Item INT,
@Id_Producto INT,
@Cantidad DECIMAL(5,2),
@Valor DECIMAL(10,2),
@Total DECIMAL(10,2),
@CodigoError INT=0 OUT,
@MensajeError VARCHAR(MAX) OUT
AS
BEGIN TRY
	INSERT INTO DETALLE_FACTURA VALUES (@Id_Factura, @Id_Item, @Id_Producto, @Cantidad, @Valor, @Total);
	SET @CodigoError=0;
	SET @MensajeError='';
END TRY
BEGIN CATCH
	SET @CodigoError=ERROR_NUMBER();
	SET @MensajeError='[insertarDetalleFactura]: '+ERROR_MESSAGE();
END CATCH;
GO
/****** Object:  StoredProcedure [dbo].[insertarFactura]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ================================================
-- Procedimiento Almacenado para Crear Facturas
-- ================================================
CREATE PROCEDURE [dbo].[insertarFactura]
@Id_Factura INT,
@Id_Cliente INT,
@Fecha DATETIME,
@CodigoError INT=0 OUT,
@MensajeError VARCHAR(MAX) OUT
AS
BEGIN TRY
	INSERT INTO FACTURA VALUES (@Id_Factura, @Id_Cliente, @Fecha); 
	SET @CodigoError=0;
	SET @MensajeError='';
END TRY
BEGIN CATCH
	SET @CodigoError=ERROR_NUMBER();
	SET @MensajeError='[insertarFactura]: '+ERROR_MESSAGE();
END CATCH;
GO
/****** Object:  StoredProcedure [dbo].[insertarPedido]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ================================================
-- Procedimiento Almacenado para Crear Pedidos
-- ================================================
CREATE PROCEDURE [dbo].[insertarPedido]
@Id_Pedido INT,
@Id_Factura INT,
@Valor_Total DECIMAL(10,2),
@Fecha DATETIME,
@Estado varchar(10),
@CodigoError INT OUTPUT,
@MensajeError VARCHAR(MAX) OUTPUT
AS
BEGIN TRY
	INSERT INTO PEDIDO VALUES (@Id_Pedido, @Id_Factura, @Valor_Total, @Fecha, @Estado); 
	SET @CodigoError=0;
	SET @MensajeError='';
END TRY
BEGIN CATCH
	SET @CodigoError=ERROR_NUMBER();
	SET @MensajeError='[insertarPedido]: '+ERROR_MESSAGE();
END CATCH;
GO
/****** Object:  StoredProcedure [dbo].[insertarProducto]    Script Date: 18/02/2023 7:55:16 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ================================================
-- Procedimiento Almacenado para Crear Productos
-- ================================================
CREATE PROCEDURE [dbo].[insertarProducto]
@Id_Producto INT,
@Nombre VARCHAR(40),
@Valor DECIMAL(10,2),
@Cantidad DECIMAL(5,2),
@CodigoError INT OUT,
@MensajeError VARCHAR(MAX) OUT
AS
BEGIN TRY
	INSERT INTO PRODUCTO VALUES (@Id_Producto,@Nombre,@Valor,@Cantidad) 
	SET @CodigoError=0;
	SET @MensajeError='';
END TRY
BEGIN CATCH
	SET @CodigoError=ERROR_NUMBER();
	SET @MensajeError='[insertarProducto] '+ERROR_MESSAGE();
END CATCH;
GO
USE [master]
GO
ALTER DATABASE [TUYADB] SET  READ_WRITE 
GO
